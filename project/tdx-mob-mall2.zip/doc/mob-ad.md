> 放广告图片，这个可以归到 mob-slider-image 中，只是一张图片而已

## 1. 效果

![mob-ad](images/mob-ad.jpg)

## 2. 调用

```
<mob-ad 
  :item="item"
/>
```

## 3. 配置

### 3.1 功能配置

```
{
  tplid: "mob-ad",
  url: "banner.png",
  split: {}
}
```

### 3.2 颜色配置

### 3.3 大小配置