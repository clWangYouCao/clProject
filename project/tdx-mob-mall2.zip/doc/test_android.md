<p class="tip">
  android 的一些测试
</p>

## tdxActivity

当当前 `View` 激活时

## Ret_Query

在 tab 的时候，左右切换会触发

## tdxRefresh

右上角配置刷新，点击刷新触发


```
tdxActivity、Ret_Query、tdxRefresh

tab 切换的时候

android Ret_Query 在 tdxActivity 前面执行
```