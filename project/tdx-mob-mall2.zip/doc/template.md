> 文档示例结构

## 1. 效果

![mob-template](images/mob-template.jpg)

## 2. 调用

```
<mob-template 
  :item="item"
  :data="data"
/>
```

`data` 格式

```
{
  key: value,
  key: value,
  ...
}
```

## 3. 配置

### 3.1 功能配置

### 3.2 颜色配置

### 3.3 大小配置