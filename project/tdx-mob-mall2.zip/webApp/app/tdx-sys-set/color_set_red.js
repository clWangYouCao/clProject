var tdx_color_red = {
  
  html: {
    "backgroundColor": "#eef2f6", 
    "color": "#333"
  },

  mobWdTab: {
    
    tabItemSel: {
      backgroundColor: "#2e6bb1",
      color: "#fff"
    }
  }
  
}