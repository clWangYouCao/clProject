var tdx_color_black = {
  
  html: {
    "backgroundColor": "rgb(16, 20, 25)", 
    "color": "#fff"
  }
}