var tdx_color = {

  html: {
    "backgroundColor": "#f5f5f5", 
    "color": "#333"
  },

  mobWdTab: {
    
    tabItemSel: {
      backgroundColor: "#2e6bb1",
      color: "#fff"
    }
  }
}