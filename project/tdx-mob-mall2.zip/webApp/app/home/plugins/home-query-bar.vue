<template>
  
  <div class="top-bar" :style="topBarStyle">
    <div class="top-bar-input">输入股票代码/首字母</div>
  </div>

</template>

<script>

return {


}

</script>
