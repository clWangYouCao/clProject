var mob_list_index = {
  items: [
    {
      tplid: "home-query-bar"
    }
  ]
}