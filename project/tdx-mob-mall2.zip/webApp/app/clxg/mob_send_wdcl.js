var GetSendData = function(n, json) {
  
  var funcid;
  var ix = new IXContent();

  switch(n) {

  }

  return [funcid, ix];
}

var SetDataField = function(data, n, vm) {
  return data;
}

window["tdxActivity"] = function() {
  window.location.href = window.location.href;
}