var mob_list_wdcl = {
  items: [
    {
      tplid: "mob-clxg-wdcl"
    }
  ]
}