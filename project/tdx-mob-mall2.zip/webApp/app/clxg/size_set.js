var tdx_size = {
  
  mobClxgWdcl: {
    clItems: {
      padding: "15px"
    }
  }
}