<template>
  
  <div>page about</div>

</template>

<script>

return {
  
}

</script>
