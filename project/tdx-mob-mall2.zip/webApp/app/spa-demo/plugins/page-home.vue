<template>
  
  <div>
    
    <a href="#" @click="jumpUrl">about</a>

  </div>

</template>

<script>

return {
  
  methods: {

    jumpUrl: function(e) {

      e.preventDefault();
      this.$root.jumpUrl("/about");
    }
  }
}
</script>
