var mob_list_fhxx = {
  items: [{
    tplid: "mob-list-page",
    index: 0,
    simpleList: 1,
    cols: [
      { title: "除息日", field: "dividend_date" },
      { title: "分红日", field: "payment_date" },
      { title: "说明", field: "payment_plan" },
    ],
    pageSize: 2000,
  }],
}