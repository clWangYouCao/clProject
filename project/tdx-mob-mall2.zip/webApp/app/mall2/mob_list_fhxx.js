var mob_list_fhxx = {
  items: [{
    index: 0,
    tplid: "mob-list-page",
    simpleList: 1,
    cols: [
      { title: "除息日", field: "dividend_date" },
      { title: "分红日", field: "payment_date" },
      { title: "说明", field: "payment_plan" },
    ],
    pageSize: 2000,
  }],
}