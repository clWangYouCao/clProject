import "commons/global.css";
import event from "commons/event.js";

import getComponent from "commons/plugin.js";

// 获取配置文件内容，mob_list_xxx.js 和 mob_send_xxx.js
import "commons/readconf.js";
import { getParams, formatSearch } from "commons/url.js";
import { getConf } from "commons/transconf.js";

const conf = getConf();
const { routes } = conf;

// vue 示例变量
let vm;

export default () => {

  if(vm) {
    event.$emit("tdxActivity");
  }
  else {

    vm = new Vue({
      el: "#app",
      data: {
        routes: routes,
        href: location.href,
        currentRoute: "/"
      },

      methods: {
        
        jumpUrl: function(url) {
          this.searchObj.route = url;
          window.history.pushState(
            { route: url},
            routes[url] || "/",
            this.pathname + formatSearch(this.searchObj)
          );
          this.href = location.href;
        }
      },

      computed: {

        pathname: function() {

          var index = this.href.indexOf("?");
          return index >= 0 ? this.href.substr(0, index) : this.href;
        },

        searchObj: function() {
          return getParams();
        },

        ViewPage() {

          let search = this.href.substr(this.href.indexOf("?") + 1);
          let params = search.split("&");
          let route;
          for(let i = 0; i < params.length; i++) {
            if(params[i].indexOf("route=") >= 0) {
              route = params[i].split("=")[1];
            }
          }

          let matchingTplid = routes[route];
          matchingTplid = matchingTplid || routes["/"];
          return getComponent(matchingTplid);
        }

      },

      render(h) {
        return h(this.ViewPage);
      }
    });
  }
}

window.addEventListener("popstate", event => {
  vm.href = location.href;
})