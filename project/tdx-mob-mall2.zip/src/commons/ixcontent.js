/*
  IXContent
*/
const IXContent = function() {
  this.cnt = [];
  this.cntJ = {};
}

IXContent.prototype.Set = function(key, value) {
  if(value && key) {
    let o = {};
    o[key] = value;
    this.cnt.push(o);
    this.cntJ[key] = value;
  }
}

IXContent.prototype.valueOf = function() {
  return this.cnt;
}

IXContent.prototype.valueOfJson = function() {
  return [this.cntJ];
}

window["IXContent"] = IXContent;