export const gddmList = [
  [0, "", 2, "", ""],
  ["F125", "F123", "F121"],
  [],
  ["0", "0000001", "测试"],
  ["1", "A000002", "测试2"]
];

export const error = [
  [-1, "请求数据出错", 0, "", ""],
  [],
  []
];

export const cardData = {
  "pro_name": "易基财富快线货币A",
  "pro_type2_name": "货币型",
  "risk_level_name": "低风险",
  "nav": "4.3012"
};