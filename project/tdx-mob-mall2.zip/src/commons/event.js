
// 这里引入调试的配置信息，发布文件时，这里要注释
// Vue.config.errorHandler = (err) => {
//   console.error(err);
// };

export default new Vue();