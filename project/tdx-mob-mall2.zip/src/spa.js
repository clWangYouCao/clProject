import run from "./url-spa";
import { onActivity } from "commons/view.js";

run();

// 定义当前 View 激活事件
if(typeof tdxActivity != "function") {
  window["tdxActivity"] = () => {
    onActivity( () => { run(); });
  };
}

// 定义刷新事件
if(typeof tdxRefresh != "function") {
  window["tdxRefresh"] = () => {
    onActivity();
  };
}

if(typeof Ret_Query != "function") {
  window["Ret_Query"] = () => {
    onActivity();
  };
}